import SwiftUI
import UIKit

@main
struct ThockApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

/// 키보드를 켜는 방법을 알려 주고, 바로 쳐 볼 수 있는 화면.
/// 소리 고르기는 키보드 맨 위 줄에서 한다 (무료 Apple ID 설치에서도 되도록 설정은 키보드 안에만 둔다)
struct ContentView: View {
    @State private var text = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("Thock 키보드")
                    .font(.largeTitle).bold()
                Text("기계식 키보드 타건음 67가지를 내는 아이폰 키보드예요.")
                    .foregroundColor(.secondary)

                step(1, "설정 앱 > 일반 > 키보드 > 키보드 > 새로운 키보드 추가… 에서 'Thock'을 고르세요.")
                step(2, "추가된 'Thock'을 눌러 '전체 접근 허용'을 켜세요. 키보드가 직접 소리를 내려면 꼭 필요해요. 이 키보드는 입력한 글자를 어디로도 보내지 않아요.")
                step(3, "글자를 칠 때 키보드 아래쪽 🌐 를 눌러 Thock으로 바꾸세요.")
                step(4, "키보드 맨 위 줄의 ♪ 소리 이름을 누르면 67가지 소리 목록과 흡음재·진동 설정이 열려요.")

                Button(action: openSettings) {
                    Text("설정 열기")
                        .bold()
                        .frame(maxWidth: .infinity)
                        .padding(12)
                }
                .background(Color.accentColor)
                .foregroundColor(.white)
                .cornerRadius(10)

                Text("여기서 바로 쳐 보세요")
                    .font(.headline)
                TextField("눌러서 입력", text: $text)
                    .textFieldStyle(RoundedBorderTextFieldStyle())

                Text("소리 크기는 아이폰 음량을 따르고, 무음 모드에서는 소리가 나지 않아요. 비밀번호 칸에서는 아이폰이 기본 키보드로 바꿔요.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
            .padding(20)
        }
    }

    private func step(_ n: Int, _ s: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Text("\(n)")
                .bold()
                .frame(width: 26, height: 26)
                .background(Circle().fill(Color.accentColor.opacity(0.15)))
            Text(s)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private func openSettings() {
        if let url = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(url)
        }
    }
}
