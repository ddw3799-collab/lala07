import Foundation
import AudioToolbox

/// 타건음 재생. 안드로이드판 SoundEngine.kt와 같은 규칙으로 파일을 고른다.
///
/// - 파일: Sounds/{스위치}_{key|space|special|enter}_{down|up}_{1..4}.wav (흡음재 버전은 앞에 foam_)
/// - 아이폰 시스템 효과음(AudioServicesPlaySystemSound)으로 낸다: 지연이 가장 짧고 여러 소리가 겹쳐도 잘 난다.
///   소리 크기는 아이폰 음량을 따르고, 무음 모드에서는 나지 않는다.
///   키보드가 직접 소리를 내려면 설정에서 '전체 접근 허용'을 켜야 한다.
final class SoundEngine {
    /// "foam_sw_mx_blue_key_down" 같은 이름 -> 불러 둔 소리들(변형 1~4)
    private var ids: [String: [SystemSoundID]] = [:]
    private var loadedSets = Set<String>()
    private var enterDownAt: TimeInterval = 0

    private var now: TimeInterval { return ProcessInfo.processInfo.systemUptime }

    /// 이 스위치 소리를 아직 안 불러왔으면 불러온다. 67가지를 전부 미리 불러오지 않고 쓰는 것만 불러온다.
    func preload(_ switchName: String, foam: Bool) {
        loadSet("", switchName)
        if foam { loadSet("foam_", switchName) }
    }

    /// prefix가 ""이면 원본 소리, "foam_"이면 흡음재 버전
    private func loadSet(_ prefix: String, _ sw: String) {
        guard SoundCatalog.ids.contains(sw), !loadedSets.contains(prefix + sw) else { return }
        loadedSets.insert(prefix + sw)
        for kind in SoundKind.allCases {
            // 다른 소리의 파일을 그대로 쓰는 소리는 그 파일을 읽는다
            let fileSw = SoundCatalog.filesFrom[sw]?[kind] ?? sw
            for dir in ["down", "up"] {
                var list: [SystemSoundID] = []
                for v in 1...SoundCatalog.maxVariants {
                    let name = "\(prefix)\(fileSw)_\(kind.rawValue)_\(dir)_\(v)"
                    guard let url = Bundle.main.url(forResource: name, withExtension: "wav", subdirectory: "Sounds") else {
                        continue
                    }
                    var sid: SystemSoundID = 0
                    if AudioServicesCreateSystemSoundID(url as CFURL, &sid) == kAudioServicesNoError {
                        list.append(sid)
                    }
                }
                if !list.isEmpty {
                    ids["\(prefix)\(sw)_\(kind.rawValue)_\(dir)"] = list
                }
            }
        }
    }

    func play(_ switchName: String, kind: SoundKind, down: Bool, foam: Bool) {
        preload(switchName, foam: foam)
        let dir = down ? "down" : "up"
        var k = kind
        // 엔터 전용 소리가 없는 소리는 특수키 소리를 쓴다
        if k == .enter && ids["\(switchName)_enter_\(dir)"] == nil { k = .special }
        // 일부 소리는 한/영·기호·시프트·백스페이스 같은 특수키도 일반 키와 같은 소리를 낸다
        if k == .special && SoundCatalog.specialAsKey.contains(switchName) { k = .key }
        let key = "\(switchName)_\(k.rawValue)_\(dir)"
        // 흡음재 소리가 없으면 원본 소리로 대신한다
        var list: [SystemSoundID]? = nil
        if foam { list = ids["foam_" + key] }
        if list == nil { list = ids[key] }
        guard let choices = list, let sid = choices.randomElement() else { return }

        // 엔터를 누른 소리(사각)와 뗀 소리(찰칵)를 나눈 소리는, 너무 빨리 떼도 사각이 묻히지 않게
        // 뗀 소리를 누른 시점부터 최소 시간이 지난 뒤에 낸다
        if k == .enter {
            if down {
                enterDownAt = now
            } else if let holdMs = SoundCatalog.enterMinHoldMs[switchName] {
                let wait = holdMs / 1000.0 - (now - enterDownAt)
                if wait > 0 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + wait) {
                        AudioServicesPlaySystemSound(sid)
                    }
                    return
                }
            }
        }
        AudioServicesPlaySystemSound(sid)
    }

    func releaseAll() {
        for list in ids.values {
            for sid in list { AudioServicesDisposeSystemSoundID(sid) }
        }
        ids.removeAll()
        loadedSets.removeAll()
    }

    deinit {
        releaseAll()
    }
}
