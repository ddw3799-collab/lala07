import Foundation

/// 키보드 설정. 키보드 안에서 고르고 키보드 안에 저장한다.
/// (무료 Apple ID로 설치하면 앱과 키보드가 설정을 나눠 쓰는 App Groups를 못 써서, 설정을 키보드 쪽에만 둔다)
final class Prefs {
    private let d = UserDefaults.standard

    /// 고른 소리. 목록에 없는 이름이면 1번 소리
    var switchName: String {
        get {
            if let s = d.string(forKey: "switch"), SoundCatalog.ids.contains(s) { return s }
            return SoundCatalog.switches[0].id
        }
        set { d.set(newValue, forKey: "switch") }
    }

    /// true면 흡음재가 들어간 것처럼 울림과 고음 여운이 줄어든 소리(foam_*.wav)
    var foam: Bool {
        get { return d.bool(forKey: "foam") }
        set { d.set(newValue, forKey: "foam") }
    }

    /// 키를 누를 때 살짝 진동 (전체 접근 허용이 켜져 있어야 나요)
    var haptic: Bool {
        get { return d.bool(forKey: "haptic") }
        set { d.set(newValue, forKey: "haptic") }
    }

    /// 마지막으로 쓴 글자판이 영어였는지
    var english: Bool {
        get { return d.bool(forKey: "english") }
        set { d.set(newValue, forKey: "english") }
    }
}
