import UIKit

/// 아이폰 기본 키보드와 비슷한 색
struct Palette {
    let background: UIColor
    let key: UIColor
    let function: UIColor
    let text: UIColor
    let keyPressed: UIColor
    let functionPressed: UIColor
    let accent: UIColor
    let shadow: UIColor
    let dark: Bool

    static func make(dark: Bool) -> Palette {
        if dark {
            return Palette(
                background: UIColor(white: 0.10, alpha: 1),
                key: UIColor(white: 0.42, alpha: 1),
                function: UIColor(white: 0.26, alpha: 1),
                text: .white,
                keyPressed: UIColor(white: 0.26, alpha: 1),
                functionPressed: UIColor(white: 0.42, alpha: 1),
                accent: UIColor.systemBlue,
                shadow: UIColor(white: 0, alpha: 0.6),
                dark: true)
        }
        return Palette(
            background: UIColor(red: 0.82, green: 0.83, blue: 0.86, alpha: 1),
            key: .white,
            function: UIColor(red: 0.67, green: 0.69, blue: 0.73, alpha: 1),
            text: .black,
            keyPressed: UIColor(red: 0.67, green: 0.69, blue: 0.73, alpha: 1),
            functionPressed: .white,
            accent: UIColor.systemBlue,
            shadow: UIColor(white: 0, alpha: 0.35),
            dark: false)
    }
}

/// 키 하나
final class KeyView: UIView {
    let def: KeyDef
    let label = UILabel()
    /// 엔터가 '검색·보내기' 같은 동작 키일 때 파란색
    var isAccent = false
    /// 시프트가 켜진 상태처럼 늘 밝게
    var isLit = false
    private(set) var isPressed = false
    private var palette = Palette.make(dark: false)

    init(def: KeyDef) {
        self.def = def
        super.init(frame: .zero)
        isUserInteractionEnabled = false   // 터치는 KeyboardView가 한꺼번에 받는다
        layer.cornerRadius = 5
        layer.shadowOffset = CGSize(width: 0, height: 1)
        layer.shadowRadius = 0
        layer.shadowOpacity = 1
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.baselineAdjustment = .alignCenters
        addSubview(label)
        label.text = def.label
        label.font = KeyView.font(for: def)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    static func font(for def: KeyDef) -> UIFont {
        switch def.type {
        case .char: return UIFont.systemFont(ofSize: 23)
        case .emoji, .emojiTab: return UIFont.systemFont(ofSize: 24)
        case .shift, .backspace: return UIFont.systemFont(ofSize: 21)
        case .globe, .emojiKey: return UIFont.systemFont(ofSize: 20)
        default: return UIFont.systemFont(ofSize: 15)
        }
    }

    func apply(_ p: Palette) {
        palette = p
        refreshColors()
    }

    func setPressed(_ on: Bool) {
        isPressed = on
        refreshColors()
    }

    func refreshColors() {
        let p = palette
        if def.type == .emoji || (def.type == .emojiTab && !isLit) {
            // 이모지는 아이폰처럼 바탕 없이
            backgroundColor = isPressed ? p.function : .clear
            layer.shadowColor = UIColor.clear.cgColor
        } else if isAccent {
            backgroundColor = isPressed ? p.functionPressed : p.accent
            layer.shadowColor = p.shadow.cgColor
        } else if def.isFunction {
            backgroundColor = (isPressed || isLit) ? p.functionPressed : p.function
            layer.shadowColor = p.shadow.cgColor
        } else {
            backgroundColor = isPressed ? p.keyPressed : p.key
            layer.shadowColor = p.shadow.cgColor
        }
        label.textColor = (isAccent && !isPressed) ? .white : p.text
        if isLit && !p.dark && def.type == .shift { label.textColor = .black }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        label.frame = bounds.insetBy(dx: 2, dy: 0)
        layer.shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: 5).cgPath
    }
}

/// 키 배열과 터치. 여러 손가락이 동시에 눌러도 손가락마다 따로 처리한다
final class KeyboardView: UIView {

    var palette = Palette.make(dark: false)
    var onDown: ((KeyView, UITouch) -> Void)?
    var onMove: ((KeyView, UITouch) -> Void)?
    var onUp: ((KeyView, UITouch) -> Void)?
    var onCancel: ((KeyView, UITouch) -> Void)?

    private(set) var rows: [[KeyDef]] = []
    private var keyViews: [[KeyView?]] = []
    /// 누를 수 있는 영역(키 사이 틈 포함)과 그 키
    private var cells: [(rect: CGRect, view: KeyView)] = []
    private var active: [ObjectIdentifier: KeyView] = [:]

    var allKeys: [KeyView] {
        return keyViews.flatMap { $0.compactMap { $0 } }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        isMultipleTouchEnabled = true
        backgroundColor = .clear
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setRows(_ newRows: [[KeyDef]], accentReturn: Bool) {
        for kv in allKeys { kv.removeFromSuperview() }
        rows = newRows
        keyViews = newRows.map { row in
            row.map { def -> KeyView? in
                if def.type == .spacer { return nil }
                let kv = KeyView(def: def)
                kv.isAccent = (def.type == .enter && accentReturn)
                kv.apply(palette)
                return kv
            }
        }
        for kv in allKeys { addSubview(kv) }
        setNeedsLayout()
    }

    func applyPalette(_ p: Palette) {
        palette = p
        for kv in allKeys { kv.apply(p) }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let sidePad: CGFloat = 3
        let topPad: CGFloat = 4
        let bottomPad: CGFloat = 4
        let rowCount = CGFloat(max(rows.count, 1))
        let rowH = (bounds.height - topPad - bottomPad) / rowCount
        let unit = (bounds.width - 2 * sidePad) / 10
        let gapX: CGFloat = 3
        let gapY: CGFloat = min(6, rowH * 0.12)
        var newCells: [(rect: CGRect, view: KeyView)] = []
        for (r, row) in rows.enumerated() {
            var x = sidePad
            let y = topPad + CGFloat(r) * rowH
            for (i, def) in row.enumerated() {
                let w = def.weight * unit
                let cell = CGRect(x: x, y: y, width: w, height: rowH)
                if r < keyViews.count, i < keyViews[r].count, let kv = keyViews[r][i] {
                    kv.frame = cell.insetBy(dx: gapX, dy: gapY)
                    newCells.append((rect: cell, view: kv))
                }
                x += w
            }
        }
        cells = newCells
    }

    /// 이 점을 누르면 어느 키인지: 칸 안이면 그 키, 빈 칸·여백이면 가장 가까운 키
    func key(at p: CGPoint) -> KeyView? {
        if let hit = cells.first(where: { $0.rect.contains(p) }), hit.view.superview != nil {
            return hit.view
        }
        var best: KeyView? = nil
        var bestD = CGFloat.greatestFiniteMagnitude
        for c in cells {
            let dx = max(c.rect.minX - p.x, 0, p.x - c.rect.maxX)
            let dy = max(c.rect.minY - p.y, 0, p.y - c.rect.maxY)
            let d = dx * dx + dy * dy
            if d < bestD {
                bestD = d
                best = c.view
            }
        }
        return best
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            guard let kv = key(at: t.location(in: self)) else { continue }
            active[ObjectIdentifier(t)] = kv
            onDown?(kv, t)
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            if let kv = active[ObjectIdentifier(t)] { onMove?(kv, t) }
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            if let kv = active.removeValue(forKey: ObjectIdentifier(t)) { onUp?(kv, t) }
        }
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            if let kv = active.removeValue(forKey: ObjectIdentifier(t)) { onCancel?(kv, t) }
        }
    }
}
