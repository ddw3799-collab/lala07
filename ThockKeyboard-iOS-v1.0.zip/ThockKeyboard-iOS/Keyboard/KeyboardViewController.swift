import UIKit

enum ShiftState {
    case off, once, lock
}

/// Thock 키보드 본체. 아이폰 기본 키보드 모양에 67가지 타건음을 입혔다.
/// 누를 때 '누르는 소리', 뗄 때 글자 입력과 '떼는 소리' (안드로이드판과 같은 순서)
final class KeyboardViewController: UIInputViewController {

    private let prefs = Prefs()
    private let sound = SoundEngine()
    private let composer = HangulComposer()
    /// 조합 중인 글자로 화면에 넣어 둔 문자열 (다음 자모가 오면 지우고 새로 넣는다)
    private var composingText = ""

    private var layer: Layer = .ko
    private var lastLetter: Layer = .ko
    private var shift: ShiftState = .off
    private var autoShifted = false
    private var lastShiftTap: TimeInterval = 0
    private var emojiPage = 0

    private let bar = SoundBar()
    private let keyboardView = KeyboardView()
    private var picker: SoundPickerView?
    private let popup = UILabel()
    private var heightConstraint: NSLayoutConstraint?
    private var renderedSignature = ""

    private var lastSpaceAt: TimeInterval = 0
    private var repeatItem: DispatchWorkItem?
    private var repeatStart: TimeInterval = 0
    private var swiping = false
    private var spaceStartX: CGFloat = 0
    private var swipeLastX: CGFloat = 0
    private let haptic = UIImpactFeedbackGenerator(style: .light)

    private let barHeight: CGFloat = 36

    private var proxy: UITextDocumentProxy { return textDocumentProxy }
    private var now: TimeInterval { return ProcessInfo.processInfo.systemUptime }

    // MARK: - 화면

    override func viewDidLoad() {
        super.viewDidLoad()
        layer = prefs.english ? .en : .ko
        lastLetter = layer

        bar.translatesAutoresizingMaskIntoConstraints = false
        keyboardView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bar)
        view.addSubview(keyboardView)
        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: view.topAnchor),
            bar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bar.heightAnchor.constraint(equalToConstant: barHeight),
            keyboardView.topAnchor.constraint(equalTo: bar.bottomAnchor),
            keyboardView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            keyboardView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            keyboardView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
        let h = view.heightAnchor.constraint(equalToConstant: keyboardHeight(landscape: isLandscape))
        h.priority = UILayoutPriority(999)
        h.isActive = true
        heightConstraint = h

        popup.textAlignment = .center
        popup.font = UIFont.systemFont(ofSize: 28)
        popup.layer.cornerRadius = 8
        popup.clipsToBounds = true
        popup.isHidden = true
        popup.isUserInteractionEnabled = false
        view.addSubview(popup)

        bar.onTap = { [weak self] in self?.togglePicker() }
        keyboardView.onDown = { [weak self] kv, t in self?.keyDown(kv, t) }
        keyboardView.onMove = { [weak self] kv, t in self?.keyMove(kv, t) }
        keyboardView.onUp = { [weak self] kv, t in self?.keyUp(kv, t) }
        keyboardView.onCancel = { [weak self] kv, _ in self?.keyCancel(kv) }

        sound.preload(prefs.switchName, foam: prefs.foam)
        render(force: true)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        heightConstraint?.constant = keyboardHeight(landscape: isLandscape)
        resetComposition()
        render(force: true)
        updateAutoShift()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopRepeat()
        hidePopup()
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        heightConstraint?.constant = keyboardHeight(landscape: size.width > size.height)
    }

    override func textWillChange(_ textInput: UITextInput?) {
        super.textWillChange(textInput)
    }

    override func textDidChange(_ textInput: UITextInput?) {
        super.textDidChange(textInput)
        syncComposing()        // 다른 입력칸으로 옮겼거나 앱이 글자를 바꿨으면 조합을 끝낸다
        render(force: false)   // 다크 모드·엔터 이름이 바뀌었을 때만 다시 그린다
        updateAutoShift()
    }

    private var isLandscape: Bool {
        let b = UIScreen.main.bounds
        return b.width > b.height
    }

    private func keyboardHeight(landscape: Bool) -> CGFloat {
        return barHeight + (landscape ? 168 : 224)
    }

    private var isDark: Bool {
        if proxy.keyboardAppearance == .dark { return true }
        return traitCollection.userInterfaceStyle == .dark
    }

    private func returnLabel() -> (String, Bool) {
        switch proxy.returnKeyType ?? .default {
        case .search, .google, .yahoo: return ("검색", true)
        case .go, .route: return ("이동", true)
        case .send: return ("보내기", true)
        case .done: return ("완료", true)
        case .next: return ("다음", false)
        case .join: return ("참여", true)
        case .continue: return ("계속", true)
        default: return ("return", false)
        }
    }

    /// 글자판을 다시 그린다. force가 아니면 모양이 바뀌었을 때만
    private func render(force: Bool) {
        let (ret, accent) = returnLabel()
        let english = (layer == .en) || (layer != .ko && lastLetter == .en)
        let symLabel: String = (layer == .ko || layer == .en) ? "123" : (lastLetter == .ko ? "가" : "ABC")
        let sig = "\(layer)|\(emojiPage)|\(isDark)|\(ret)|\(accent)|\(needsInputModeSwitchKey)|\(english)"
        if !force && sig == renderedSignature { return }
        renderedSignature = sig

        let p = Palette.make(dark: isDark)
        view.backgroundColor = p.background
        popup.backgroundColor = p.dark ? UIColor(white: 0.42, alpha: 1) : .white
        popup.textColor = p.text
        keyboardView.applyPalette(p)
        keyboardView.setRows(
            Layouts.rows(layer: layer, globe: needsInputModeSwitchKey, symLabel: symLabel,
                         spaceLabel: english ? "space" : "스페이스", returnLabel: ret, emojiPage: emojiPage),
            accentReturn: accent)
        refreshShift()
        updateBar()
    }

    private func updateBar() {
        let p = Palette.make(dark: isDark)
        if !hasFullAccess {
            bar.update(title: "⚠︎ 소리를 내려면 설정 > Thock > '전체 접근 허용'을 켜 주세요", warning: true, palette: p)
            return
        }
        let foam = prefs.foam ? " · 흡음재" : ""
        bar.update(title: "♪ " + SoundCatalog.label(prefs.switchName) + foam + "  ▾", warning: false, palette: p)
    }

    private func refreshShift() {
        let on = shift != .off
        for kv in keyboardView.allKeys {
            switch kv.def.type {
            case .char:
                kv.label.text = on ? kv.def.shiftLabel : kv.def.label
            case .shift:
                kv.label.text = shift == .lock ? "⇪" : "⇧"
                kv.isLit = on
                kv.refreshColors()
            case .emojiTab:
                kv.isLit = kv.def.page == emojiPage
                kv.refreshColors()
            default:
                break
            }
        }
    }

    // MARK: - 터치

    private func keyDown(_ kv: KeyView, _ t: UITouch) {
        let def = kv.def
        kv.setPressed(true)
        playSound(def, down: true)
        if prefs.haptic && hasFullAccess { haptic.impactOccurred() }
        switch def.type {
        case .char, .emoji:
            showPopup(kv)
        case .backspace:
            doBackspace()
            startRepeat()
        case .shift:
            toggleShift()
        case .symbols:
            toggleSymbols()
        case .symPage:
            finishComposing()
            layer = (layer == .num) ? .sym : .num
            render(force: true)
        case .emojiKey:
            finishComposing()
            layer = .emoji
            shift = .off
            render(force: true)
        case .emojiTab:
            emojiPage = max(0, def.page)
            render(force: true)
        case .space:
            swiping = false
            spaceStartX = t.location(in: keyboardView).x
            swipeLastX = spaceStartX
        default:
            break
        }
    }

    private func keyMove(_ kv: KeyView, _ t: UITouch) {
        guard kv.def.type == .space else { return }
        // 스페이스바를 옆으로 밀면 커서 이동 (안드로이드판과 같이)
        let x = t.location(in: keyboardView).x
        if !swiping && abs(x - spaceStartX) > 12 {
            swiping = true
            finishComposing()
            swipeLastX = x
        }
        guard swiping else { return }
        let step: CGFloat = 9
        let moved = Int((x - swipeLastX) / step)
        if moved != 0 {
            proxy.adjustTextPosition(byCharacterOffset: moved)
            swipeLastX += CGFloat(moved) * step
            if prefs.haptic && hasFullAccess { haptic.impactOccurred(intensity: 0.4) }
        }
    }

    private func keyUp(_ kv: KeyView, _ t: UITouch) {
        let def = kv.def
        kv.setPressed(false)
        hidePopup()
        switch def.type {
        case .char:
            typeChar(shift != .off ? def.shiftLabel : def.label)
            if shift == .once {
                shift = .off
                autoShifted = false
                refreshShift()
            }
        case .emoji:
            typeText(def.label)
        case .space:
            if !swiping { typeSpace() }
            swiping = false
        case .enter:
            finishComposing()
            proxy.insertText("\n")
        case .lang:
            toggleLanguage()
        case .globe:
            advanceToNextInputMode()
        case .backspace:
            stopRepeat()
        default:
            break
        }
        playSound(def, down: false)
        updateAutoShift()
    }

    private func keyCancel(_ kv: KeyView) {
        kv.setPressed(false)
        hidePopup()
        if kv.def.type == .backspace { stopRepeat() }
        if kv.def.type == .space { swiping = false }
    }

    private func playSound(_ def: KeyDef, down: Bool) {
        let kind: SoundKind
        switch def.type {
        case .char, .emoji: kind = .key
        case .space: kind = .space
        case .enter: kind = .enter
        default: kind = .special
        }
        sound.play(prefs.switchName, kind: kind, down: down, foam: prefs.foam)
    }

    private func showPopup(_ kv: KeyView) {
        // 맨 아래 줄과 이모지 탭에는 말풍선을 띄우지 않는다
        guard kv.def.type == .char || kv.def.type == .emoji else { return }
        let r = keyboardView.convert(kv.frame, to: view)
        popup.text = kv.label.text
        let w = max(r.width + 14, 40)
        let h = r.height + 10
        var x = r.midX - w / 2
        x = min(max(2, x), view.bounds.width - w - 2)
        let y = max(0, r.minY - h - 4)
        popup.frame = CGRect(x: x, y: y, width: w, height: h)
        popup.isHidden = false
        view.bringSubviewToFront(popup)
    }

    private func hidePopup() {
        popup.isHidden = true
    }

    // MARK: - 글자 넣기 (한글 조합)

    /// 커서가 옮겨졌거나 앱이 글자를 바꿔서 조합 중인 글자가 화면 끝에 없으면 조합을 끝낸다
    private func syncComposing() {
        guard composer.isComposing else { return }
        if let before = proxy.documentContextBeforeInput, !before.hasSuffix(composingText) {
            resetComposition()
        }
    }

    private func resetComposition() {
        composer.reset()
        composingText = ""
    }

    /// 조합 중인 글자(이미 화면에 넣어 둔 것)를 지우고 새 문자열로 바꾼다
    private func replaceComposing(with s: String) {
        for _ in 0..<composingText.count { proxy.deleteBackward() }
        if !s.isEmpty { proxy.insertText(s) }
    }

    private func typeChar(_ s: String) {
        if layer == .ko, s.count == 1, let c = s.first, HangulComposer.isJamo(c) {
            typeJamo(c)
        } else {
            typeText(s)
        }
    }

    private func typeJamo(_ c: Character) {
        syncComposing()
        let done = composer.input(c)
        let composing = composer.composing()
        replaceComposing(with: done + composing)
        composingText = composing
    }

    private func typeText(_ s: String) {
        finishComposing()
        proxy.insertText(s)
    }

    /// 조합 중인 글자는 이미 화면에 들어가 있으니 상태만 비운다
    private func finishComposing() {
        resetComposition()
    }

    private func typeSpace() {
        finishComposing()
        // 스페이스를 빠르게 두 번 누르면 마침표 + 스페이스 (아이폰과 같이)
        let t = now
        if t - lastSpaceAt < 0.45, let before = proxy.documentContextBeforeInput, before.hasSuffix(" ") {
            let trimmed = before.dropLast()
            if let prev = trimmed.last, !prev.isWhitespace, !".,?!".contains(prev) {
                proxy.deleteBackward()
                proxy.insertText(". ")
                lastSpaceAt = 0
                return
            }
        }
        proxy.insertText(" ")
        lastSpaceAt = t
    }

    private func doBackspace() {
        syncComposing()
        if composer.isComposing {
            _ = composer.backspace()
            let composing = composer.composing()
            replaceComposing(with: composing)
            composingText = composing
        } else {
            proxy.deleteBackward()
        }
    }

    // 백스페이스를 꾹 누를 때: 처음 3초는 같은 속도, 3초부터 점점 빨라지고 6초에 최고 속도 (안드로이드판과 같이)
    private func repeatInterval(_ held: TimeInterval) -> TimeInterval {
        let base = 0.045, fastest = 0.010
        if held < 3 { return base }
        let k = min(1, (held - 3) / 3)
        return base + (fastest - base) * k
    }

    private func startRepeat() {
        stopRepeat()
        repeatStart = now
        scheduleRepeat(after: 0.4)
    }

    private func scheduleRepeat(after delay: TimeInterval) {
        let item = DispatchWorkItem { [weak self] in self?.repeatTick() }
        repeatItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: item)
    }

    private func repeatTick() {
        guard repeatItem != nil else { return }
        let held = now - repeatStart
        let perTick = held >= 6 ? 2 : 1
        for _ in 0..<perTick { doBackspace() }
        scheduleRepeat(after: repeatInterval(held))
    }

    private func stopRepeat() {
        repeatItem?.cancel()
        repeatItem = nil
    }

    // MARK: - 글자판 바꾸기

    private func toggleShift() {
        let t = now
        switch shift {
        case .off: shift = .once
        case .once: shift = (t - lastShiftTap < 0.35) ? .lock : .off
        case .lock: shift = .off
        }
        autoShifted = false
        lastShiftTap = t
        refreshShift()
    }

    private func toggleSymbols() {
        finishComposing()
        if layer == .ko || layer == .en {
            layer = .num
        } else {
            layer = lastLetter
        }
        shift = .off
        render(force: true)
    }

    private func toggleLanguage() {
        finishComposing()
        let base: Layer = (layer == .ko || layer == .en) ? layer : lastLetter
        let next: Layer = (base == .ko) ? .en : .ko
        lastLetter = next
        layer = next
        prefs.english = (next == .en)
        shift = .off
        render(force: true)
    }

    /// 영어 글자판에서 문장 첫 글자는 자동으로 대문자 (입력칸이 원할 때만)
    private func updateAutoShift() {
        guard layer == .en, shift != .lock else { return }
        let type = proxy.autocapitalizationType ?? .sentences
        let before = proxy.documentContextBeforeInput ?? ""
        var cap = false
        switch type {
        case .sentences:
            let trimmed = before.trimmingCharacters(in: .whitespaces)
            cap = before.isEmpty || before.hasSuffix("\n")
                || (before.hasSuffix(" ") && (trimmed.hasSuffix(".") || trimmed.hasSuffix("!") || trimmed.hasSuffix("?")))
        case .words:
            cap = before.isEmpty || before.hasSuffix(" ") || before.hasSuffix("\n")
        case .allCharacters:
            cap = true
        default:
            cap = false
        }
        if cap && shift == .off {
            shift = .once
            autoShifted = true
            refreshShift()
        } else if !cap && shift == .once && autoShifted {
            shift = .off
            autoShifted = false
            refreshShift()
        }
    }

    // MARK: - 소리 고르기

    private func togglePicker() {
        if let p = picker {
            p.removeFromSuperview()
            picker = nil
            return
        }
        let p = SoundPickerView(selected: prefs.switchName, foam: prefs.foam, haptic: prefs.haptic,
                                palette: Palette.make(dark: isDark))
        p.onSelect = { [weak self] id in self?.selectSound(id) }
        p.onFoam = { [weak self] on in
            guard let self = self else { return }
            self.prefs.foam = on
            self.sound.preload(self.prefs.switchName, foam: on)
            self.updateBar()
            self.previewSound()
        }
        p.onHaptic = { [weak self] on in self?.prefs.haptic = on }
        p.onClose = { [weak self] in self?.togglePicker() }
        p.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(p)
        NSLayoutConstraint.activate([
            p.topAnchor.constraint(equalTo: keyboardView.topAnchor),
            p.leadingAnchor.constraint(equalTo: keyboardView.leadingAnchor),
            p.trailingAnchor.constraint(equalTo: keyboardView.trailingAnchor),
            p.bottomAnchor.constraint(equalTo: keyboardView.bottomAnchor),
        ])
        picker = p
        view.layoutIfNeeded()
        p.scrollToSelected()
    }

    private func selectSound(_ id: String) {
        prefs.switchName = id
        sound.preload(id, foam: prefs.foam)
        updateBar()
        previewSound()
    }

    /// 고른 소리를 한 번 들려준다 (누르는 소리 → 0.09초 뒤 떼는 소리)
    private func previewSound() {
        let id = prefs.switchName
        let foam = prefs.foam
        sound.play(id, kind: .key, down: true, foam: foam)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.09) { [weak self] in
            self?.sound.play(id, kind: .key, down: false, foam: foam)
        }
    }
}
