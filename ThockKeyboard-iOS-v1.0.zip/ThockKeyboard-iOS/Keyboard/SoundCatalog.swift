import Foundation

// 이 파일은 안드로이드판 v4.0.0(MainActivity.kt·SoundEngine.kt·Layouts.kt)에서 자동으로 옮겨 적었어요.
// 소리를 바꾸거나 더하면 안드로이드판과 같이 맞춰 주세요.

enum SoundKind: String, CaseIterable {
    case key, space, special, enter
}

enum SoundCatalog {
    /// 설정 목록 순서 그대로 (번호 = 위치 + 1)
    static let switches: [(id: String, label: String)] = [
        ("deep_14_silent", "1. 극저소음 먹먹 딥 톡 (유지)"),
        ("deep_7_milky_yellow", "2. 우유뚜껑 황축 크리미 톡 (유지)"),
        ("deep_1_muddy", "3. 먹먹한 극저음 딥 톡 (유지)"),
        ("thock_heavy", "4. 고압 80g 스프링 톡 (유지)"),
        ("thock_black_cherry", "5. 흑축 풀윤활 톡 (유지)"),
        ("remaster_ebony_wood", "6. 푸른 주사위 또렷한 아크릴 클랙"),
        ("remaster_gateron_ink_v2", "7. 단단한 민트 청량한 하이톤 도각"),
        ("remaster_boba_u4t_heavy", "8. 카일 박스 제이드(옥축) 찰칵 클리키"),
        ("remaster_holy_panda", "9. 카일 박스 화이트(백축) 경쾌한 클릭"),
        ("remaster_topre_45g", "10. 유리구슬 마작패 맑은 부딪힘"),
        ("remaster_ceramic_keycap", "11. 박하사탕 부딪히는 청량한 틱"),
        ("remaster_retro_typewriter", "12. 마이크로 스위치(마우스 클릭) 또깍 틱"),
        ("remaster_brass_heavy_nobrass", "13. 황동 뺀 정갈하고 단단한 딥 톡"),
        ("video_deep_sea", "14. 심해 바다 RGB 키보드 (영상 원음, 날카롭고 밝은 클릭)"),
        ("video_blue_dice", "15. 푸른 주사위 (영상 원음, 맑은 클릭)"),
        ("video_pink_wax", "16. 핑크 실링왁스 (영상 원음, 묵직한 톡)"),
        ("video_pink_wax2", "17. 핑크 실링왁스 보완 (스페이스·엔터 따로)"),
        ("video_sagak3", "18. 사각사각 보완 (스페이스=길게 스치는 소리 24%)"),
        ("video_hanguk", "19. 한국의 미 (영상 원음, 스페이스·엔터 따로)"),
        ("video_sagak4", "20. 사각사각 보완 (스페이스=길게 스치는 소리 16%)"),
        ("video_bogle2", "21. 보글보글 도곡도곡 긴 녹음 (영상 원음, 스페이스·엔터 따로)"),
        ("video_hanguk2", "22. 한국의 미 긴 녹음 (엔터만 영상 속 사각·찰칵, 나머지 특수키는 일반 키 소리)"),
        ("video_milky_yellow", "23. Classic Sensibility 루브 게이트론 밀키 옐로우 (영상 원음, 스페이스·엔터 따로)"),
        ("asmr_marshmallow", "24. 마시멜로 크리미 톡 (ASMR 배합, 스페이스·엔터 따로)"),
        ("asmr_raindrop", "25. 처마 끝 빗방울 톡 (ASMR 배합, 스페이스·엔터 따로)"),
        ("asmr_marble", "26. 대리석 조약돌 클랙 (ASMR 배합, 스페이스·엔터 따로)"),
        ("asmr_cotton", "27. 솜이불 속 먹먹한 톡 (ASMR 배합, 스페이스·엔터 따로)"),
        ("asmr_porcelain", "28. 도자기 찻잔 딸깍 (ASMR 배합, 스페이스·엔터 따로)"),
        ("asmr_jelly", "29. 젤리곰 말랑 톡 (ASMR 배합, 스페이스·엔터 따로)"),
        ("asmr_cave", "30. 동굴 속 울리는 묵직한 톡 (ASMR 배합, 스페이스·엔터 따로)"),
        ("asmr_popcorn", "31. 팝콘 터지는 톡톡 (ASMR 배합, 스페이스·엔터 따로)"),
        ("asmr_chocolate", "32. 초콜릿 똑 부러지는 톡 (ASMR 배합, 스페이스·엔터 따로)"),
        ("asmr_glass", "33. 얼음 유리잔 맑은 틱 (ASMR 배합, 스페이스·엔터 따로)"),
        ("asmr_mochi", "34. 찹쌀떡 쫀득 톡 (ASMR 배합, 스페이스·엔터 따로)"),
        ("asmr_dawn_silent", "35. 새벽 저소음 딥 톡 (합성 · 취향 맞춤, 스페이스·엔터 따로)"),
        ("asmr_fingertip", "36. 손끝으로 원목 테이블 톡톡 (합성 · 창작, 스페이스=손바닥, 엔터=노크)"),
        ("video_hanguk3", "37. 한국의 미 보완 (영상 원음, 엔터는 사각·찰칵 4가지, 나머지 특수키는 일반 키 소리)"),
        ("video_hanguk4", "38. 한국의 미 보완 부드럽게 (스치는 고음 살짝 뺌, 엔터 사각 줄임 4가지)"),
        ("video_hanguk5", "39. 한국의 미 보완 + 22번 일반 키 (스페이스·엔터는 38번)"),
        ("video_crystal", "40. 물방울 크리스탈 투명 키캡 (영상 원음, 스페이스·엔터 따로, 특수키는 일반 키 소리)"),
        ("video_bluejelly", "41. 흰색·파란 젤리 키캡 (영상 원음, 스페이스·엔터 따로, 특수키는 일반 키 소리)"),
        ("video_pinkjelly", "42. 분홍 반투명 젤리 키캡 (영상 원음, 스페이스·엔터 따로, 특수키는 일반 키 소리)"),
        ("sw_mx_blue", "43. 체리 청축 (MX Blue) · 또렷한 클릭 재킷 '찰칵' (청축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_gateron_blue", "44. 게이트론 청축 · 가볍고 밝은 클릭 (청축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_mx_green", "45. 체리 녹축 (MX Green) · 묵직한 80g 클릭 (청축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_box_navy", "46. 카일 박스 네이비 · 두꺼운 클릭바 '탁' (청축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_box_pink", "47. 카일 박스 핑크 · 가볍고 높은 클릭바 (청축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_buckling", "48. IBM 버클링 스프링 (모델 M) · 철컥 + 스프링 울림 (청축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_alps_blue", "49. 알프스 SKCM 청축 · 날카롭고 짧은 고음 클릭 (청축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_deep_clicky", "50. 청축 + 두꺼운 PBT·흡음 · 딥한 클릭 톡 (청축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_mx_brown", "51. 체리 갈축 (MX Brown) · 은은한 걸림 + 살짝 사각 (갈축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_gateron_brown", "52. 게이트론 갈축 · 둥글고 부드러운 걸림 (갈축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_boba_u4", "53. 게이즈 보바 U4 · 조용하고 먹먹한 저소음 택타일 (갈축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_boba_u4t", "54. 보바 U4T · 둥글고 깊은 딥 택타일 (갈축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_mx_clear", "55. 체리 클리어축 (MX Clear) · 무겁고 큰 걸림 (갈축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_zealios", "56. 제지알 질리오스 V2 · 또렷한 걸림 + 맑은 고음 클랙 (갈축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_durock_t1", "57. 듀록 T1 · 톡 튀는 걸림 '도곡' (갈축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_mx_red", "58. 체리 적축 (MX Red) · 가볍고 매끈한 클랙 (적축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_oil_king", "59. 게이트론 오일킹 · 깊고 매끈한 딥 톡 (적축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_nk_cream", "60. NK 크림 (POM) · 크리미한 사각 클랙 (적축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_vintage_black", "61. 체리 빈티지 흑축 · 묵직한 서걱 리니어 (적축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_speed_silver", "62. 체리 은축 (Speed Silver) · 짧고 빠른 '틱' (적축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_silent_red", "63. 저소음 적축 · 먹먹하고 조용한 톡 (적축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_tangerine", "64. 탠저린 · 톡톡 튀는 맑은 마블 클랙 (적축 계열 리마스터, 스페이스·엔터 따로)"),
        ("sw_ink_black", "65. 게이트론 잉크 블랙 V2 · 깊고 매끈한 유리 클랙 (적축 계열 리마스터, 스페이스·엔터 따로)"),
        ("video_pinkjelly2", "66. 분홍 반투명 젤리 키캡 보완 · 일반 키 4가지 (튀던 1개를 나머지와 같게, 스페이스·엔터는 42번, 특수키는 일반 키 소리)"),
        ("video_pinkjelly3", "67. 분홍 반투명 젤리 키캡 보완 · 일반 키 4가지 + 찰칵 고음 살림 (튀던 1개는 크기만 맞추고 날카로운 고음은 절반만 낮춤, 스페이스·엔터는 42번)"),
    ]

    static let ids: Set<String> = Set(switches.map { $0.id })

    static func label(_ id: String) -> String {
        return switches.first(where: { $0.id == id })?.label ?? id
    }

    /// 한 소리당 변형 최대 개수. 대부분 3벌이고, 37~39번 엔터와 66·67번 일반 키만 4벌
    static let maxVariants = 4

    /// 엔터만 전용 소리를 쓰고, 나머지 특수키(시프트·백스페이스·123·한/영 등)는 일반 키 소리를 쓰는 소리
    static let specialAsKey: Set<String> = [
        "video_hanguk2", "video_hanguk3", "video_hanguk4", "video_hanguk5",
        "video_crystal", "video_bluejelly", "video_pinkjelly", "video_pinkjelly2",
        "video_pinkjelly3", "sw_mx_blue", "sw_gateron_blue", "sw_mx_green",
        "sw_box_navy", "sw_box_pink", "sw_buckling", "sw_alps_blue",
        "sw_deep_clicky", "sw_mx_brown", "sw_gateron_brown", "sw_boba_u4",
        "sw_boba_u4t", "sw_mx_clear", "sw_zealios", "sw_durock_t1",
        "sw_mx_red", "sw_oil_king", "sw_nk_cream", "sw_vintage_black",
        "sw_speed_silver", "sw_silent_red", "sw_tangerine", "sw_ink_black",
    ]

    /// 엔터 '뗄 때 소리'를 누른 시점부터 최소 이만큼(ms) 뒤에 낸다
    static let enterMinHoldMs: [String: Double] = [
        "video_hanguk2": 200,
        "video_hanguk3": 200,
        "video_hanguk4": 200,
        "video_hanguk5": 200,
    ]

    /// 자기 파일 없이 다른 소리의 파일을 그대로 쓰는 소리 (종류별로)
    static let filesFrom: [String: [SoundKind: String]] = [
        "video_sagak4": [.key: "video_sagak3", .special: "video_sagak3"],
        "video_hanguk5": [.key: "video_hanguk2", .space: "video_hanguk4", .enter: "video_hanguk4"],
        "video_pinkjelly2": [.space: "video_pinkjelly", .enter: "video_pinkjelly"],
        "video_pinkjelly3": [.space: "video_pinkjelly", .enter: "video_pinkjelly"],
    ]

    /// 이모지 화면: 탭 7개, 탭마다 30개(3줄 x 10)
    static let emojiTabs: [String] = ["😀", "👍", "❤️", "🐶", "🍔", "⚽", "💡"]
    static let emojiPages: [[String]] = [
        ["😀", "😃", "😄", "😁", "😆", "😅", "🤣", "😂", "🙂", "😉", "😊", "😇", "🥰", "😍", "🤩", "😘", "😋", "😛", "😜", "🤪", "🤔", "🤗", "😎", "🥳", "😏", "😒", "🙄", "😴", "😢", "😭"],
        ["👍", "👎", "👌", "✌️", "🤞", "🤟", "🤘", "🤙", "👈", "👉", "👆", "👇", "☝️", "✋", "🤚", "🖐️", "👋", "👏", "🙌", "🙏", "💪", "🤝", "✍️", "👀", "👂", "👃", "👄", "🧠", "🦷", "🤲"],
        ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔", "❣️", "💕", "💞", "💓", "💗", "💖", "💘", "💝", "💯", "💢", "💥", "💫", "💦", "💨", "✨", "🔥", "⭐", "🌟", "✅", "❌"],
        ["🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐨", "🐯", "🦁", "🐮", "🐷", "🐸", "🐵", "🐔", "🐧", "🐦", "🐤", "🦆", "🦉", "🐺", "🐴", "🦄", "🐝", "🦋", "🐢", "🐙", "🐬", "🐳"],
        ["🍎", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🍒", "🍑", "🥝", "🍅", "🥑", "🥕", "🌽", "🍞", "🧀", "🍳", "🥓", "🍔", "🍟", "🍕", "🌭", "🍜", "🍣", "🍙", "🍦", "🍩", "🍪", "☕", "🍺"],
        ["⚽", "🏀", "🏈", "⚾", "🎾", "🏐", "🎱", "🏓", "🏸", "🥊", "🎮", "🎯", "🎲", "🎵", "🎤", "🎧", "🎸", "🚗", "🚕", "🚌", "🚀", "✈️", "🚲", "🏠", "🏖️", "🌍", "🌈", "☀️", "🌙", "⛄"],
        ["💡", "📱", "💻", "⌨️", "🖱️", "📷", "📺", "🔋", "🔑", "💰", "💳", "🎁", "🎉", "🎂", "📚", "✏️", "📌", "📎", "✂️", "🔒", "🔔", "⏰", "📅", "📝", "🧸", "🎈", "🏆", "👑", "💎", "🔍"],
    ]
}
