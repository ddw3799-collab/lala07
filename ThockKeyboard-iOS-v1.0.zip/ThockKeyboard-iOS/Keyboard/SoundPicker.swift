import UIKit

/// 키보드 맨 위 얇은 줄: 지금 소리 이름. 누르면 소리 목록이 열린다
final class SoundBar: UIView {
    var onTap: (() -> Void)?
    private let button = UIButton(type: .custom)

    override init(frame: CGRect) {
        super.init(frame: frame)
        button.contentHorizontalAlignment = .left
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        button.titleLabel?.lineBreakMode = .byTruncatingTail
        button.addTarget(self, action: #selector(tapped), for: .touchUpInside)
        addSubview(button)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        button.frame = bounds.insetBy(dx: 12, dy: 0)
    }

    func update(title: String, warning: Bool, palette: Palette) {
        button.setTitle(title, for: .normal)
        let color: UIColor = warning ? UIColor.systemOrange : palette.text
        button.setTitleColor(color, for: .normal)
        button.setTitleColor(color.withAlphaComponent(0.5), for: .highlighted)
    }

    @objc private func tapped() {
        onTap?()
    }
}

/// 소리 고르기 화면 (키보드 자리를 덮는다): 67가지 목록 + 흡음재·진동
final class SoundPickerView: UIView, UITableViewDataSource, UITableViewDelegate {
    var onSelect: ((String) -> Void)?
    var onFoam: ((Bool) -> Void)?
    var onHaptic: ((Bool) -> Void)?
    var onClose: (() -> Void)?

    private var selectedId: String
    private let table = UITableView(frame: .zero, style: .plain)
    private let header = UIView()
    private let titleLabel = UILabel()
    private let foamLabel = UILabel()
    private let foamSwitch = UISwitch()
    private let hapticLabel = UILabel()
    private let hapticSwitch = UISwitch()
    private let closeButton = UIButton(type: .system)
    private let palette: Palette

    init(selected: String, foam: Bool, haptic: Bool, palette: Palette) {
        self.selectedId = selected
        self.palette = palette
        super.init(frame: .zero)
        backgroundColor = palette.background

        titleLabel.text = "소리 \(SoundCatalog.switches.count)가지"
        titleLabel.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
        titleLabel.textColor = palette.text
        foamLabel.text = "흡음재"
        hapticLabel.text = "진동"
        for l in [foamLabel, hapticLabel] {
            l.font = UIFont.systemFont(ofSize: 13)
            l.textColor = palette.text
            l.textAlignment = .right
        }
        foamSwitch.isOn = foam
        hapticSwitch.isOn = haptic
        foamSwitch.transform = CGAffineTransform(scaleX: 0.75, y: 0.75)
        hapticSwitch.transform = CGAffineTransform(scaleX: 0.75, y: 0.75)
        foamSwitch.addTarget(self, action: #selector(foamChanged), for: .valueChanged)
        hapticSwitch.addTarget(self, action: #selector(hapticChanged), for: .valueChanged)
        closeButton.setTitle("완료", for: .normal)
        closeButton.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
        closeButton.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)
        for v in [titleLabel, foamLabel, foamSwitch, hapticLabel, hapticSwitch, closeButton] as [UIView] {
            header.addSubview(v)
        }
        addSubview(header)

        table.dataSource = self
        table.delegate = self
        table.backgroundColor = .clear
        table.rowHeight = UITableView.automaticDimension
        table.estimatedRowHeight = 44
        table.register(UITableViewCell.self, forCellReuseIdentifier: "c")
        addSubview(table)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let h: CGFloat = 40
        header.frame = CGRect(x: 0, y: 0, width: bounds.width, height: h)
        table.frame = CGRect(x: 0, y: h, width: bounds.width, height: max(0, bounds.height - h))
        // 오른쪽부터: 완료 | 진동 [스위치] | 흡음재 [스위치], 왼쪽에 제목
        var x = bounds.width - 8
        closeButton.frame = CGRect(x: x - 50, y: 0, width: 50, height: h)
        x -= 56
        let sw = foamSwitch.frame.width
        hapticSwitch.center = CGPoint(x: x - sw / 2, y: h / 2)
        x -= sw + 2
        hapticLabel.frame = CGRect(x: x - 32, y: 0, width: 32, height: h)
        x -= 40
        foamSwitch.center = CGPoint(x: x - sw / 2, y: h / 2)
        x -= sw + 2
        foamLabel.frame = CGRect(x: x - 44, y: 0, width: 44, height: h)
        x -= 50
        titleLabel.frame = CGRect(x: 12, y: 0, width: max(40, x - 12), height: h)
    }

    func scrollToSelected() {
        guard let i = SoundCatalog.switches.firstIndex(where: { $0.id == selectedId }) else { return }
        table.layoutIfNeeded()
        table.scrollToRow(at: IndexPath(row: i, section: 0), at: .middle, animated: false)
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return SoundCatalog.switches.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "c", for: indexPath)
        let item = SoundCatalog.switches[indexPath.row]
        cell.textLabel?.text = item.label
        cell.textLabel?.numberOfLines = 2
        cell.textLabel?.font = UIFont.systemFont(ofSize: 14)
        cell.textLabel?.textColor = palette.text
        cell.backgroundColor = .clear
        cell.tintColor = palette.accent
        cell.accessoryType = item.id == selectedId ? .checkmark : .none
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        selectedId = SoundCatalog.switches[indexPath.row].id
        tableView.reloadData()
        onSelect?(selectedId)
    }

    @objc private func foamChanged() {
        onFoam?(foamSwitch.isOn)
    }

    @objc private func hapticChanged() {
        onHaptic?(hapticSwitch.isOn)
    }

    @objc private func closeTapped() {
        onClose?()
    }
}
