package com.thock.touchprobe

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.util.SparseArray
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * 도록 터치 측정 (테스트 앱)
 *
 * 화면 아래 키보드 모양 칸을 실제로 타자 치듯 눌러서, 손가락이 닿은 면적(touchMajor·touchMinor), size, pressure가
 * '살살'과 '세게'에서 얼마나 갈리는지 잰다. 키보드 앱에 '치는 세기에 따라 다른 소리'를 넣을 수 있는지 판단하려는 용도.
 *
 *  - 누른 순간 값(소리는 이 순간에 나야 해서 실제로 쓸 수 있는 값)과
 *    누르는 동안 가장 큰 값, 16ms·33ms 시점 값을 따로 기록한다
 *  - 커버 화면·메인 화면을 기록마다 표시해서, 접고 펴며 한 번에 잴 수 있다
 *  - 'CSV 복사'로 기록 전체를 복사해 붙여 넣을 수 있다
 */
class MainActivity : Activity() {

    // ---------- 기록 ----------
    class Tap(
        val mode: Int,            // 0 살살, 1 세게
        val inner: Boolean,       // 메인(펼친) 화면
        val downMajor: Float, val downMinor: Float, val downSize: Float, val downPressure: Float,
        val major16: Float, val major33: Float,
        val maxMajor: Float, val maxSize: Float, val maxPressure: Float,
        val durMs: Long, val tool: Int, val key: Int,
    )

    private val taps = ArrayList<Tap>()
    private var mode = 0

    private lateinit var statsView: TextView
    private lateinit var lastView: TextView
    private lateinit var infoView: TextView
    private lateinit var softBtn: Button
    private lateinit var hardBtn: Button
    private lateinit var pad: PadView

    private val d get() = resources.displayMetrics.density
    private fun dp(v: Float) = (v * d).toInt()

    private val BURGUNDY = Color.parseColor("#7D2F3E")
    private val INK = Color.parseColor("#2A2627")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#F6F1EE"))
        root.setPadding(dp(14f), dp(28f), dp(14f), dp(10f))

        val title = TextView(this)
        title.text = "도록 터치 측정"
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.setTextColor(BURGUNDY)
        root.addView(title)

        infoView = TextView(this)
        infoView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        infoView.setTextColor(Color.parseColor("#6E6467"))
        root.addView(infoView)

        // 살살 / 세게 / 초기화 / 복사
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(0, dp(8f), 0, dp(6f))
        softBtn = btn("살살") { mode = 0; refreshMode() }
        hardBtn = btn("세게") { mode = 1; refreshMode() }
        val clr = btn("초기화") { taps.clear(); refresh() }
        val cp = btn("CSV 복사") { copyCsv() }
        for (b in listOf(softBtn, hardBtn, clr, cp)) {
            val lp = LinearLayout.LayoutParams(0, dp(44f), 1f)
            lp.setMargins(dp(3f), 0, dp(3f), 0)
            bar.addView(b, lp)
        }
        root.addView(bar)

        val sv = ScrollView(this)
        val inner = LinearLayout(this)
        inner.orientation = LinearLayout.VERTICAL
        statsView = TextView(this)
        statsView.typeface = Typeface.MONOSPACE
        statsView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        statsView.setTextColor(INK)
        inner.addView(statsView)
        lastView = TextView(this)
        lastView.typeface = Typeface.MONOSPACE
        lastView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        lastView.setTextColor(Color.parseColor("#6E6467"))
        lastView.setPadding(0, dp(8f), 0, 0)
        inner.addView(lastView)
        sv.addView(inner)
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        pad = PadView(this)
        root.addView(pad, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(4 * 42f + 3 * 10f + 24f)))

        setContentView(root)
        refreshMode()
        refresh()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        refresh()
        pad.requestLayout()
    }

    private fun btn(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun bgOf(on: Boolean): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(10f).toFloat()
        g.setColor(if (on) BURGUNDY else Color.WHITE)
        return g
    }

    private fun refreshMode() {
        softBtn.background = bgOf(mode == 0); softBtn.setTextColor(if (mode == 0) Color.WHITE else INK)
        hardBtn.background = bgOf(mode == 1); hardBtn.setTextColor(if (mode == 1) Color.WHITE else INK)
    }

    /** 메인(펼친) 화면: 화면 짧은 변 600dp 이상 (도록 키보드 v4.25와 같은 기준) */
    private fun isInner(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 30) {
                val b = windowManager.maximumWindowMetrics.bounds
                minOf(b.width(), b.height()) / d >= 600f
            } else resources.configuration.smallestScreenWidthDp >= 600
        } catch (e: Exception) {
            resources.configuration.smallestScreenWidthDp >= 600
        }
    }

    // ---------- 통계 ----------
    private class St(val n: Int, val mean: Float, val sd: Float, val uniq: Int)

    private fun st(v: List<Float>): St {
        if (v.isEmpty()) return St(0, 0f, 0f, 0)
        val m = v.average().toFloat()
        val sd = if (v.size > 1) sqrt(v.sumOf { ((it - m) * (it - m)).toDouble() }.toFloat() / (v.size - 1)) else 0f
        return St(v.size, m, sd, v.map { (it * 1000f).toInt() }.toSet().size)
    }

    /** 두 무리가 얼마나 갈리는지: 평균 차이 ÷ 둘을 합친 표준편차 (1 미만 거의 안 갈림, 1~2 조금, 2 이상 확실) */
    private fun sep(a: St, b: St): Float {
        if (a.n < 2 || b.n < 2) return Float.NaN
        val pooled = sqrt((a.sd * a.sd + b.sd * b.sd) / 2f)
        if (pooled <= 1e-6f) return if (abs(a.mean - b.mean) > 1e-6f) 99f else 0f
        return abs(b.mean - a.mean) / pooled
    }

    private fun fmt(v: Float): String = if (v.isNaN()) "  -  " else String.format("%6.2f", v)

    private fun refresh() {
        val inner = isInner()
        val cfg = resources.configuration
        infoView.text = "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE}\n" +
            "지금 화면: ${if (inner) "메인(펼친)" else "커버(접은)"} · ${cfg.screenWidthDp}×${cfg.screenHeightDp}dp · 밀도 ${"%.2f".format(d)}\n" +
            "모드를 고른 뒤, 아래 칸을 평소 타자 치듯 20번 이상 눌러 주세요. 살살 → 세게 순서로."

        val sb = StringBuilder()
        for (scr in listOf(false, true)) {
            val s = taps.filter { it.inner == scr }
            if (s.isEmpty()) continue
            val soft = s.filter { it.mode == 0 }; val hard = s.filter { it.mode == 1 }
            sb.append(if (scr) "■ 메인 화면" else "■ 커버 화면").append("  (살살 ${soft.size} · 세게 ${hard.size})\n")
            sb.append("값              살살 평균±편차      세게 평균±편차     갈림\n")
            fun row(name: String, f: (Tap) -> Float) {
                val a = st(soft.map(f)); val b = st(hard.map(f))
                sb.append(String.format("%-12s %s±%s  %s±%s  %s\n", name, fmt(a.mean), fmt(a.sd).trim(), fmt(b.mean), fmt(b.sd).trim(), fmt(sep(a, b))))
            }
            row("면적(누른순간)", { it.downMajor })
            row("면적(16ms)", { it.major16 })
            row("면적(33ms)", { it.major33 })
            row("면적(최대)", { it.maxMajor })
            row("size(누른순간)", { it.downSize })
            row("size(최대)", { it.maxSize })
            row("압력(누른순간)", { it.downPressure })
            row("압력(최대)", { it.maxPressure })
            row("누른시간ms", { it.durMs.toFloat() })
            val all = st(s.map { it.downMajor })
            sb.append("누른 순간 면적 값 종류: ${all.uniq}가지 (1~2가지면 이 기기는 면적을 거의 안 줌)\n\n")
        }
        if (sb.isEmpty()) sb.append("아직 기록이 없어요.\n")
        sb.append("갈림: 1 미만 = 거의 안 갈림 · 1~2 = 조금 · 2 이상 = 확실히 갈림\n")
        statsView.text = sb.toString()

        val last = taps.takeLast(8).reversed()
        lastView.text = if (last.isEmpty()) "" else "최근 기록 (면적px: 순간/16ms/33ms/최대 · size · 압력 · ms)\n" +
            last.joinToString("\n") { t ->
                String.format("%s %s  %5.1f/%5.1f/%5.1f/%5.1f  %.3f  %.3f  %3d",
                    if (t.mode == 0) "살살" else "세게", if (t.inner) "메인" else "커버",
                    t.downMajor, t.major16, t.major33, t.maxMajor, t.downSize, t.downPressure, t.durMs)
            }
    }

    private fun copyCsv() {
        val sb = StringBuilder()
        sb.append("# ${Build.MANUFACTURER} ${Build.MODEL} Android ${Build.VERSION.RELEASE} density=${d}\n")
        sb.append("mode,screen,downMajor,downMinor,downSize,downPressure,major16,major33,maxMajor,maxSize,maxPressure,durMs,tool,key\n")
        for (t in taps) {
            sb.append(if (t.mode == 0) "soft" else "hard").append(',').append(if (t.inner) "main" else "cover").append(',')
                .append(t.downMajor).append(',').append(t.downMinor).append(',').append(t.downSize).append(',').append(t.downPressure).append(',')
                .append(t.major16).append(',').append(t.major33).append(',').append(t.maxMajor).append(',').append(t.maxSize).append(',')
                .append(t.maxPressure).append(',').append(t.durMs).append(',').append(t.tool).append(',').append(t.key).append('\n')
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("touch probe", sb.toString()))
        Toast.makeText(this, "기록 ${taps.size}개를 복사했어요", Toast.LENGTH_SHORT).show()
    }

    // ---------- 키보드 모양 칸 ----------
    private inner class Live(val t0: Long, val key: Int) {
        var downMajor = 0f; var downMinor = 0f; var downSize = 0f; var downPressure = 0f
        var major16 = Float.NaN; var major33 = Float.NaN
        var maxMajor = 0f; var maxSize = 0f; var maxPressure = 0f
        var tool = 0
        fun sample(tMs: Long, major: Float, size: Float, pressure: Float) {
            val age = tMs - t0
            if (age <= 16) major16 = major
            if (age <= 33) major33 = major
            maxMajor = max(maxMajor, major); maxSize = max(maxSize, size); maxPressure = max(maxPressure, pressure)
        }
    }

    private inner class PadView(ctx: Context) : View(ctx) {
        private val rows = intArrayOf(10, 9, 9, 7)
        private val keys = ArrayList<RectF>()
        private val down = HashSet<Int>()
        private val live = SparseArray<Live>()
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            keys.clear()
            val padX = dp(6f).toFloat(); val gap = dp(6f).toFloat(); val rowGap = dp(10f).toFloat(); val kh = dp(42f).toFloat()
            val unit = (w - 2 * padX) / 10f
            var y = dp(12f).toFloat()
            for ((r, n) in rows.withIndex()) {
                if (r == 3) {
                    // 맨 아래 줄: 작은 키 2개 · 스페이스 · 작은 키 2개 (스페이스 = 5칸)
                    val ws = floatArrayOf(1.25f, 1.25f, 5f, 1.25f, 1.25f)
                    var x = padX
                    for (wk in ws) { keys.add(RectF(x + gap / 2, y, x + wk * unit - gap / 2, y + kh)); x += wk * unit }
                } else {
                    val off = (10 - n) * unit / 2f
                    for (i in 0 until n) { val x = padX + off + i * unit; keys.add(RectF(x + gap / 2, y, x + unit - gap / 2, y + kh)) }
                }
                y += kh + rowGap
            }
        }

        override fun onDraw(c: Canvas) {
            c.drawColor(Color.parseColor("#E4E5E7"))
            val r = dp(8f).toFloat()
            for ((i, k) in keys.withIndex()) {
                p.color = if (i in down) BURGUNDY else Color.WHITE
                c.drawRoundRect(k, r, r, p)
            }
        }

        private fun keyAt(x: Float, y: Float): Int = keys.indexOfFirst { it.contains(x, y) }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val now = SystemClock.uptimeMillis()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    val i = e.actionIndex
                    val id = e.getPointerId(i)
                    val k = keyAt(e.getX(i), e.getY(i))
                    val l = Live(e.eventTime, k)
                    l.downMajor = e.getTouchMajor(i); l.downMinor = e.getTouchMinor(i)
                    l.downSize = e.getSize(i); l.downPressure = e.getPressure(i)
                    l.tool = e.getToolType(i)
                    l.sample(e.eventTime, l.downMajor, l.downSize, l.downPressure)
                    live.put(id, l)
                    if (k >= 0) { down.add(k); invalidate() }
                }
                MotionEvent.ACTION_MOVE -> {
                    for (i in 0 until e.pointerCount) {
                        val l = live.get(e.getPointerId(i)) ?: continue
                        for (h in 0 until e.historySize) {
                            l.sample(e.getHistoricalEventTime(h), e.getHistoricalTouchMajor(i, h), e.getHistoricalSize(i, h), e.getHistoricalPressure(i, h))
                        }
                        l.sample(e.eventTime, e.getTouchMajor(i), e.getSize(i), e.getPressure(i))
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                    val i = e.actionIndex
                    val id = e.getPointerId(i)
                    val l = live.get(id)
                    if (l != null) {
                        live.remove(id)
                        if (l.key >= 0) down.remove(l.key)
                        if (e.actionMasked != MotionEvent.ACTION_CANCEL && l.key >= 0) {
                            l.sample(e.eventTime, e.getTouchMajor(i), e.getSize(i), e.getPressure(i))
                            taps.add(Tap(mode, isInner(), l.downMajor, l.downMinor, l.downSize, l.downPressure,
                                if (l.major16.isNaN()) l.downMajor else l.major16, if (l.major33.isNaN()) l.downMajor else l.major33,
                                l.maxMajor, l.maxSize, l.maxPressure, e.eventTime - l.t0, l.tool, l.key))
                            refresh()
                        }
                        invalidate()
                    }
                    if (e.actionMasked == MotionEvent.ACTION_CANCEL) { live.clear(); down.clear(); invalidate() }
                }
            }
            return true
        }
    }
}
