import UIKit

enum KeyType {
    case char, shift, backspace, space, enter
    case symbols      // 123 / 가 / ABC: 글자판 <-> 숫자판
    case symPage      // #+= / 123: 숫자판 <-> 기호판
    case lang         // 한/영
    case emojiKey     // 😀: 이모지 화면 열기
    case emoji        // 이모지 한 개
    case emojiTab     // 이모지 분류 탭
    case globe        // 🌐: 다음 키보드 (홈 버튼 있는 아이폰에서만 보인다)
    case spacer       // 빈 칸 (누르면 가장 가까운 키)
}

enum Layer {
    case ko, en, num, sym, emoji
}

struct KeyDef {
    let type: KeyType
    let label: String
    let shiftLabel: String
    let weight: CGFloat
    let page: Int

    init(_ type: KeyType, _ label: String = "", shift: String? = nil, weight: CGFloat = 1, page: Int = -1) {
        self.type = type
        self.label = label
        self.shiftLabel = shift ?? label
        self.weight = weight
        self.page = page
    }

    /// 회색(기능) 키인지. 글자·스페이스·이모지는 흰 키
    var isFunction: Bool {
        switch type {
        case .char, .space, .emoji: return false
        default: return true
        }
    }
}

/// 아이폰 기본 키보드와 비슷한 배열. 한 줄 너비는 10칸(weight 합 10)
enum Layouts {

    private static func chars(_ normal: String, _ shifted: String? = nil, weight: CGFloat = 1) -> [KeyDef] {
        let n = Array(normal).map { String($0) }
        let s = Array(shifted ?? normal).map { String($0) }
        var out: [KeyDef] = []
        for i in 0..<n.count {
            out.append(KeyDef(.char, n[i], shift: i < s.count ? s[i] : n[i], weight: weight))
        }
        return out
    }

    private static func letters(_ r1: String, _ r1s: String, _ r2: String, _ r2s: String,
                                _ r3: String, _ r3s: String) -> [[KeyDef]] {
        return [
            chars(r1, r1s),
            [KeyDef(.spacer, weight: 0.5)] + chars(r2, r2s) + [KeyDef(.spacer, weight: 0.5)],
            [KeyDef(.shift, "⇧", weight: 1.3), KeyDef(.spacer, weight: 0.2)] + chars(r3, r3s)
                + [KeyDef(.spacer, weight: 0.2), KeyDef(.backspace, "⌫", weight: 1.3)],
        ]
    }

    private static func bottom(symLabel: String, globe: Bool, spaceLabel: String, returnLabel: String) -> [KeyDef] {
        var row: [KeyDef] = [KeyDef(.symbols, symLabel, weight: 1.25)]
        if globe { row.append(KeyDef(.globe, "🌐", weight: 1.0)) }
        row.append(KeyDef(.emojiKey, "😀", weight: globe ? 1.0 : 1.25))
        row.append(KeyDef(.lang, "한/영", weight: globe ? 1.0 : 1.25))
        let enterWeight: CGFloat = 2.5
        let used = row.reduce(CGFloat(0)) { $0 + $1.weight } + enterWeight
        row.append(KeyDef(.space, spaceLabel, weight: 10 - used))
        row.append(KeyDef(.enter, returnLabel, weight: enterWeight))
        return row
    }

    static func rows(layer: Layer, globe: Bool, symLabel: String, spaceLabel: String,
                     returnLabel: String, emojiPage: Int) -> [[KeyDef]] {
        let bottomRow = bottom(symLabel: symLabel, globe: globe, spaceLabel: spaceLabel, returnLabel: returnLabel)
        switch layer {
        case .ko:
            return letters("ㅂㅈㄷㄱㅅㅛㅕㅑㅐㅔ", "ㅃㅉㄸㄲㅆㅛㅕㅑㅒㅖ",
                           "ㅁㄴㅇㄹㅎㅗㅓㅏㅣ", "ㅁㄴㅇㄹㅎㅗㅓㅏㅣ",
                           "ㅋㅌㅊㅍㅠㅜㅡ", "ㅋㅌㅊㅍㅠㅜㅡ") + [bottomRow]
        case .en:
            return letters("qwertyuiop", "QWERTYUIOP",
                           "asdfghjkl", "ASDFGHJKL",
                           "zxcvbnm", "ZXCVBNM") + [bottomRow]
        case .num:
            return [
                chars("1234567890"),
                chars("-/:;()₩&@\""),
                [KeyDef(.symPage, "#+=", weight: 1.3)] + chars(".,?!'", weight: 1.48) + [KeyDef(.backspace, "⌫", weight: 1.3)],
                bottomRow,
            ]
        case .sym:
            return [
                chars("[]{}#%^*+="),
                chars("_\\|~<>$£¥•"),
                [KeyDef(.symPage, "123", weight: 1.3)] + chars(".,?!'", weight: 1.48) + [KeyDef(.backspace, "⌫", weight: 1.3)],
                bottomRow,
            ]
        case .emoji:
            let pageIndex = max(0, min(emojiPage, SoundCatalog.emojiPages.count - 1))
            let list = SoundCatalog.emojiPages[pageIndex]
            var rows: [[KeyDef]] = []
            for r in 0..<3 {
                let slice = list.dropFirst(r * 10).prefix(10)
                rows.append(slice.map { KeyDef(.emoji, $0) })
            }
            var tabs: [KeyDef] = [KeyDef(.symbols, symLabel, weight: 1.5)]
            for (i, t) in SoundCatalog.emojiTabs.enumerated() {
                tabs.append(KeyDef(.emojiTab, t, weight: 1.0, page: i))
            }
            tabs.append(KeyDef(.backspace, "⌫", weight: 1.5))
            rows.append(tabs)
            return rows
        }
    }
}
