import Foundation

/// 두벌식 한글 조합 오토마타. 안드로이드판 HangulComposer.java를 그대로 옮겼어요.
///
/// 사용법: input(자모)이 "먼저 확정할 글자"를 돌려주고, 이어서 composing()이
/// "지금 조합 중인 글자"를 돌려준다.
final class HangulComposer {

    private static let CHO: [Character] = Array("ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ")
    private static let JUNG: [Character] = Array("ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ")
    /// 0번 칸은 받침 없음
    private static let JONG: [Character] = Array(" ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ")

    /// (앞, 뒤, 결과) 3글자씩
    private static let JUNG_TABLE: [Character] = Array("ㅗㅏㅘㅗㅐㅙㅗㅣㅚㅜㅓㅝㅜㅔㅞㅜㅣㅟㅡㅣㅢ")
    private static let JONG_TABLE: [Character] =
        Array("ㄱㅅㄳㄴㅈㄵㄴㅎㄶㄹㄱㄺㄹㅁㄻㄹㅂㄼㄹㅅㄽㄹㅌㄾㄹㅍㄿㄹㅎㅀㅂㅅㅄ")

    private var cho: Character? = nil
    private var jung: Character? = nil
    private var jong: Character? = nil

    static func isJamo(_ c: Character) -> Bool {
        return CHO.contains(c) || JUNG.contains(c)
    }

    var isComposing: Bool {
        return cho != nil || jung != nil
    }

    func reset() {
        cho = nil
        jung = nil
        jong = nil
    }

    /// 조합 중인 글자를 돌려주고 상태를 비운다.
    func flush() -> String {
        let s = composing()
        reset()
        return s
    }

    /// 지금 조합 중인 글자 (없으면 빈 문자열)
    func composing() -> String {
        guard let j = jung else {
            if let c = cho { return String(c) }
            return ""
        }
        guard let c = cho else { return String(j) }
        let ci = HangulComposer.CHO.firstIndex(of: c) ?? 0
        let ji = HangulComposer.JUNG.firstIndex(of: j) ?? 0
        var ki = 0
        if let k = jong, let i = HangulComposer.JONG.firstIndex(of: k) {
            ki = i
        }
        let code = 0xAC00 + (ci * 21 + ji) * 28 + ki
        guard let scalar = Unicode.Scalar(UInt32(code)) else { return "" }
        return String(Character(scalar))
    }

    /// 자모 하나를 입력한다. 먼저 확정(commit)해야 하는 글자를 돌려준다. 없으면 빈 문자열.
    func input(_ c: Character) -> String {
        let vowel = HangulComposer.JUNG.contains(c)
        let cons = HangulComposer.CHO.contains(c)
        if !vowel && !cons {
            return flush() + String(c)
        }

        // 초성+중성+종성
        if let jg = jong {
            if vowel {
                let newCho: Character
                if let first = HangulComposer.splitFirst(HangulComposer.JONG_TABLE, jg) {
                    newCho = HangulComposer.splitSecond(HangulComposer.JONG_TABLE, jg) ?? jg
                    jong = first
                } else {
                    newCho = jg
                    jong = nil
                }
                let done = composing()
                cho = newCho
                jung = c
                jong = nil
                return done
            }
            if let comb = HangulComposer.combine(HangulComposer.JONG_TABLE, jg, c) {
                jong = comb
                return ""
            }
            let done = composing()
            cho = c
            jung = nil
            jong = nil
            return done
        }

        // 초성+중성
        if cho != nil, let jn = jung {
            if cons {
                if let i = HangulComposer.JONG.firstIndex(of: c), i > 0 {
                    jong = c
                    return ""
                }
                let done = composing()
                cho = c
                jung = nil
                return done
            }
            if let comb = HangulComposer.combine(HangulComposer.JUNG_TABLE, jn, c) {
                jung = comb
                return ""
            }
            let done = composing()
            cho = nil
            jung = c
            return done
        }

        // 초성만
        if cho != nil {
            if cons {
                let done = composing()
                cho = c
                return done
            }
            jung = c
            return ""
        }

        // 모음만
        if let jn = jung {
            if vowel {
                if let comb = HangulComposer.combine(HangulComposer.JUNG_TABLE, jn, c) {
                    jung = comb
                    return ""
                }
                let done = composing()
                jung = c
                return done
            }
            let done = composing()
            jung = nil
            cho = c
            return done
        }

        // 비어 있음
        if cons {
            cho = c
        } else {
            jung = c
        }
        return ""
    }

    /// 조합 중인 글자에서 자모 하나를 지운다.
    /// 조합 중인 글자가 있어서 처리했으면 true, 비어 있으면 false (false면 실제로 한 글자를 지워야 한다)
    func backspace() -> Bool {
        if let jg = jong {
            jong = HangulComposer.splitFirst(HangulComposer.JONG_TABLE, jg)
            return true
        }
        if let jn = jung {
            jung = HangulComposer.splitFirst(HangulComposer.JUNG_TABLE, jn)
            return true
        }
        if cho != nil {
            cho = nil
            return true
        }
        return false
    }

    private static func combine(_ table: [Character], _ a: Character, _ b: Character) -> Character? {
        var i = 0
        while i + 2 < table.count {
            if table[i] == a && table[i + 1] == b {
                return table[i + 2]
            }
            i += 3
        }
        return nil
    }

    private static func splitFirst(_ table: [Character], _ result: Character) -> Character? {
        var i = 0
        while i + 2 < table.count {
            if table[i + 2] == result {
                return table[i]
            }
            i += 3
        }
        return nil
    }

    private static func splitSecond(_ table: [Character], _ result: Character) -> Character? {
        var i = 0
        while i + 2 < table.count {
            if table[i + 2] == result {
                return table[i + 1]
            }
            i += 3
        }
        return nil
    }
}
